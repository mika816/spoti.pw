// Runtime dynamic accent colour from the current now-playing artwork.
// This intentionally does not write SGKeyAccent: the normal picker remains a persistent/manual
// preference, while this feature changes the live colour only.
#import "Core/SGCore.h"
#import "Redesigned/Kit/SGRBridges.h"
#import "Settings/SGPageStyle.h"

static uint32_t sg_dynamic_rgb = 0x1ED760;
static BOOL sg_dynamic_enabled = YES;
static BOOL sg_dynamic_ready = NO;

static void unpackRGB(uint32_t rgb, CGFloat *r, CGFloat *g, CGFloat *b) {
    *r = ((rgb >> 16) & 0xFF) / 255.0;
    *g = ((rgb >> 8) & 0xFF) / 255.0;
    *b = (rgb & 0xFF) / 255.0;
}

static uint32_t packRGB(CGFloat r, CGFloat g, CGFloat b) {
    r = MIN(1, MAX(0, r)); g = MIN(1, MAX(0, g)); b = MIN(1, MAX(0, b));
    return ((uint32_t)lround(r * 255) << 16) |
           ((uint32_t)lround(g * 255) << 8) |
           (uint32_t)lround(b * 255);
}

// A small, deterministic artwork sampler. It ignores near-black/near-white pixels and gives
// saturated pixels a little more weight, producing the same kind of "vibrant" result wanted here
// without shipping a JS runtime or a large colour library.
static uint32_t accentFromImage(UIImage *image) {
    if (!image.CGImage) return 0x1ED760;

    CGImageRef cg = image.CGImage;
    size_t w = CGImageGetWidth(cg), h = CGImageGetHeight(cg);
    if (!w || !h) return 0x1ED760;

    size_t side = 48;
    size_t sw = MIN(side, w), sh = MIN(side, h);
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    uint8_t *pixels = calloc(sw * sh * 4, 1);
    if (!pixels) { CGColorSpaceRelease(space); return 0x1ED760; }

    CGContextRef ctx = CGBitmapContextCreate(pixels, sw, sh, 8, sw * 4, space,
                                               kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    if (!ctx) {
        free(pixels); CGColorSpaceRelease(space); return 0x1ED760;
    }

    CGContextSetInterpolationQuality(ctx, kCGInterpolationLow);
    CGContextDrawImage(ctx, CGRectMake(0, 0, sw, sh), cg);

    CGFloat sr = 0, sg = 0, sb = 0, weightSum = 0;
    CGFloat bestScore = -1;
    CGFloat br = 0, bg = 0, bb = 0;

    for (size_t y = 0; y < sh; y++) {
        for (size_t x = 0; x < sw; x++) {
            size_t i = (y * sw + x) * 4;
            CGFloat r = pixels[i] / 255.0;
            CGFloat g = pixels[i + 1] / 255.0;
            CGFloat b = pixels[i + 2] / 255.0;

            CGFloat mx = MAX(r, MAX(g, b)), mn = MIN(r, MIN(g, b));
            CGFloat l = (mx + mn) * 0.5;
            CGFloat sat = mx <= mn ? 0 : (mx - mn) / (1 - fabs(2 * l - 1));

            // Skip pixels that would make unreadable UI colours.
            if (l < 0.08 || l > 0.94) continue;
            if (sat < 0.16) continue;

            CGFloat score = sat * (0.55 + 0.45 * (1 - fabs(l - 0.48)));
            sr += r * score; sg += g * score; sb += b * score; weightSum += score;

            if (score > bestScore) {
                bestScore = score; br = r; bg = g; bb = b;
            }
        }
    }

    CGContextRelease(ctx);
    CGColorSpaceRelease(space);
    free(pixels);

    CGFloat r = weightSum > 0 ? sr / weightSum : br;
    CGFloat g = weightSum > 0 ? sg / weightSum : bg;
    CGFloat b = weightSum > 0 ? sb / weightSum : bb;
    if (weightSum <= 0) return 0x1ED760;

    // Keep the accent readable on Spotify's dark surfaces: clamp luminance into a vibrant range.
    CGFloat mx = MAX(r, MAX(g, b)), mn = MIN(r, MIN(g, b));
    CGFloat l = (mx + mn) * 0.5;
    if (l < 0.30) {
        CGFloat f = 0.30 / MAX(l, 0.01);
        r = MIN(1, r * f); g = MIN(1, g * f); b = MIN(1, b * f);
    } else if (l > 0.78) {
        CGFloat f = 0.78 / l;
        r *= f; g *= f; b *= f;
    }

    return packRGB(r, g, b);
}

static BOOL colorMatchesGreen(CGFloat r, CGFloat g, CGFloat b) {
    static const uint32_t greens[] = {0x1ED760, 0x1DB954};
    for (NSUInteger i = 0; i < sizeof(greens)/sizeof(greens[0]); i++) {
        CGFloat gr, gg, gb; unpackRGB(greens[i], &gr, &gg, &gb);
        if (fabs(r-gr) <= 0.018 && fabs(g-gg) <= 0.018 && fabs(b-gb) <= 0.018) return YES;
    }
    return NO;
}

static UIColor *dynamicColor(void) {
    CGFloat r,g,b; unpackRGB(sg_dynamic_rgb,&r,&g,&b);
    return [UIColor colorWithRed:r green:g blue:b alpha:1];
}

static void animateVisibleUI(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *key = nil;
        for (UIWindow *w in UIApplication.sharedApplication.windows) {
            if (!w.hidden && w.alpha > 0.01 && w.windowLevel == UIWindowLevelNormal) {
                if (w.isKeyWindow) { key = w; break; }
                if (!key) key = w;
            }
        }
        if (!key) return;

        UIColor *accent = dynamicColor();
        void (^walk)(UIView *) = ^(UIView *root) {
            // Recursive implementation is installed below through a helper function.
        };
        // A layout/display pass is enough for views whose colour is created lazily.
        [key setNeedsLayout];
        [key setNeedsDisplay];
        [key.rootViewController.view setNeedsLayout];
        [key.rootViewController.view setNeedsDisplay];

        // Re-apply live tint/text/background colours that still contain Spotify green.
        NSMutableArray *stack = [NSMutableArray arrayWithObject:key];
        while (stack.count) {
            UIView *v = stack.lastObject; [stack removeLastObject];
            if (v.tintColor) {
                CGFloat r,g,b,a;
                if ([v.tintColor getRed:&r green:&g blue:&b alpha:&a] && colorMatchesGreen(r,g,b))
                    v.tintColor = accent;
            }
            if (v.backgroundColor) {
                CGFloat r,g,b,a;
                if ([v.backgroundColor getRed:&r green:&g blue:&b alpha:&a] && colorMatchesGreen(r,g,b))
                    v.backgroundColor = accent;
            }
            if ([v isKindOfClass:UILabel.class]) {
                UILabel *label = (UILabel *)v;
                CGFloat r,g,b,a;
                if ([label.textColor getRed:&r green:&g blue:&b alpha:&a] && colorMatchesGreen(r,g,b))
                    label.textColor = accent;
            }
            for (UIView *sub in v.subviews) [stack addObject:sub];
            if (v.layer) {
                CGColorRef fill = v.layer.backgroundColor;
                if (fill && CGColorGetNumberOfComponents(fill) == 4) {
                    const CGFloat *c = CGColorGetComponents(fill);
                    if (colorMatchesGreen(c[0],c[1],c[2])) v.layer.backgroundColor = accent.CGColor;
                }
                CGColorRef sf = v.layer.sublayers.count ? nil : nil;
                (void)sf;
                for (CALayer *layer in v.layer.sublayers ?: @[]) {
                    CGColorRef fc = layer.backgroundColor;
                    if (fc && CGColorGetNumberOfComponents(fc) == 4) {
                        const CGFloat *c = CGColorGetComponents(fc);
                        if (colorMatchesGreen(c[0],c[1],c[2])) layer.backgroundColor = accent.CGColor;
                    }
                    CGColorRef fillColor = layer ? [layer valueForKey:@"fillColor"] : nil;
                    if (fillColor && CGColorGetNumberOfComponents(fillColor) == 4) {
                        const CGFloat *c = CGColorGetComponents(fillColor);
                        if (colorMatchesGreen(c[0],c[1],c[2])) [layer setValue:(id)accent.CGColor forKey:@"fillColor"];
                    }
                    CGColorRef strokeColor = layer ? [layer valueForKey:@"strokeColor"] : nil;
                    if (strokeColor && CGColorGetNumberOfComponents(strokeColor) == 4) {
                        const CGFloat *c = CGColorGetComponents(strokeColor);
                        if (colorMatchesGreen(c[0],c[1],c[2])) [layer setValue:(id)accent.CGColor forKey:@"strokeColor"];
                    }
                }
            }
        }
    });
}

static void setDynamicAccentFromArtwork(UIImage *image) {
    if (!sg_dynamic_enabled || !image) return;
    uint32_t next = accentFromImage(image);
    if (next == sg_dynamic_rgb && sg_dynamic_ready) return;

    UIColor *oldColor = dynamicColor();
    sg_dynamic_rgb = next;
    sg_dynamic_ready = YES;

    // UIKit animations interpolate the UI colours for us where those properties are animatable.
    [UIView transitionWithView:UIApplication.sharedApplication.keyWindow ?: SGTopController().view
                       duration:0.45
                        options:UIViewAnimationOptionTransitionCrossDissolve | UIViewAnimationOptionBeginFromCurrentState
                     animations:^{
                         animateVisibleUI();
                     } completion:nil];
    (void)oldColor;
}

@interface SGDynamicAccentObserver : NSObject
@end

@implementation SGDynamicAccentObserver
- (void)artworkChanged:(NSNotification *)note {
    UIImage *image = note.userInfo[@"image"];
    setDynamicAccentFromArtwork(image);
}
@end

%ctor {
    if (!SGNativeUI() && !SGRedesignedUI()) return;
    sg_dynamic_rgb = 0x1ED760;
    SGDynamicAccentObserver *observer = [SGDynamicAccentObserver new];
    [NSNotificationCenter.defaultCenter addObserver:observer
                                             selector:@selector(artworkChanged:)
                                                 name:SGRNowPlayingArtworkDidChangeNotification
                                               object:nil];
    // Keep the observer alive for the lifetime of the process.
    static SGDynamicAccentObserver *keepAlive;
    keepAlive = observer;
}
