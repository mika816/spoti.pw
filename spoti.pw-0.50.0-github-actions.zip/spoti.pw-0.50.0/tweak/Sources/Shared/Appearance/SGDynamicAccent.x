// Dynamic accent colour for both Spotify looks.
// The redesigned Kit already publishes the current artwork through
// "spotifyglass.redesign.nowPlayingArtworkDidChange". We intentionally listen by notification name
// instead of importing Redesigned/ so the Native and Redesigned layers can both use this source.
#import "Core/SGCore.h"
#import "SGDynamicAccent.h"

static const uint32_t kDefaultDynamicAccent = 0x1ED760;
static uint32_t sg_dynamic_rgb = kDefaultDynamicAccent;
static uint32_t sg_previous_rgb = kDefaultDynamicAccent;
static BOOL sg_dynamic_ready = NO;

BOOL SGDynamicAccentEnabled(void) {
    // Reserved as a preference for a future settings switch. Dynamic colour is enabled by default.
    return ![[NSUserDefaults standardUserDefaults] boolForKey:@"spotifyglass.dynamicAccent.disabled"];
}

uint32_t SGDynamicAccentRGB(void) {
    return sg_dynamic_rgb;
}

static void unpackRGB(uint32_t rgb, CGFloat *r, CGFloat *g, CGFloat *b) {
    *r = ((rgb >> 16) & 0xFF) / 255.0;
    *g = ((rgb >> 8) & 0xFF) / 255.0;
    *b = (rgb & 0xFF) / 255.0;
}

static uint32_t packRGB(CGFloat r, CGFloat g, CGFloat b) {
    r = MIN(1, MAX(0, r)); g = MIN(1, MAX(0, g)); b = MIN(1, MAX(0, b));
    return ((uint32_t)lround(r * 255) << 16) |
           ((uint32_t)lround(g * 255) << 8) |
           (uint32_t)lround(b * 255);
}

static uint32_t accentFromImage(UIImage *image) {
    if (!image.CGImage) return kDefaultDynamicAccent;

    CGImageRef cg = image.CGImage;
    size_t w = CGImageGetWidth(cg), h = CGImageGetHeight(cg);
    if (!w || !h) return kDefaultDynamicAccent;

    const size_t side = 48;
    size_t sw = MIN(side, w), sh = MIN(side, h);
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    if (!space) return kDefaultDynamicAccent;

    uint8_t *pixels = calloc(sw * sh * 4, 1);
    if (!pixels) { CGColorSpaceRelease(space); return kDefaultDynamicAccent; }

    CGContextRef ctx = CGBitmapContextCreate(pixels, sw, sh, 8, sw * 4, space,
                                               kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    if (!ctx) {
        free(pixels); CGColorSpaceRelease(space); return kDefaultDynamicAccent;
    }

    CGContextSetInterpolationQuality(ctx, kCGInterpolationLow);
    CGContextDrawImage(ctx, CGRectMake(0, 0, sw, sh), cg);

    CGFloat sr = 0, sg = 0, sb = 0, total = 0;
    CGFloat best = 0, br = 0, bg = 0, bb = 0;

    for (size_t y = 0; y < sh; y++) {
        for (size_t x = 0; x < sw; x++) {
            size_t i = (y * sw + x) * 4;
            CGFloat r = pixels[i] / 255.0, g = pixels[i + 1] / 255.0, b = pixels[i + 2] / 255.0;
            CGFloat mx = MAX(r, MAX(g, b)), mn = MIN(r, MIN(g, b));
            CGFloat l = (mx + mn) * 0.5;
            CGFloat sat = mx <= mn ? 0 : (mx - mn) / MAX(0.0001, (1 - fabs(2 * l - 1)));

            // Remove black/white/grey artwork pixels that make poor accent colours.
            if (l < 0.08 || l > 0.94 || sat < 0.14) continue;

            // Saturation is preferred, but mid-tone colours win over neon highlights and shadows.
            CGFloat score = sat * (0.50 + 0.50 * (1 - fabs(l - 0.48)));
            sr += r * score; sg += g * score; sb += b * score; total += score;

            if (score > best) {
                best = score; br = r; bg = g; bb = b;
            }
        }
    }

    CGContextRelease(ctx);
    CGColorSpaceRelease(space);
    free(pixels);

    if (total <= 0) return kDefaultDynamicAccent;

    CGFloat r = sr / total, g = sg / total, b = sb / total;
    if (best > 0 && total < 0.5) { r = br; g = bg; b = bb; }

    CGFloat mx = MAX(r, MAX(g, b)), mn = MIN(r, MIN(g, b));
    CGFloat l = (mx + mn) * 0.5;
    if (l < 0.30) {
        CGFloat f = 0.30 / MAX(l, 0.01);
        r = MIN(1, r * f); g = MIN(1, g * f); b = MIN(1, b * f);
    } else if (l > 0.78) {
        CGFloat f = 0.78 / l;
        r *= f; g *= f; b *= f;
    }
    return packRGB(r, g, b);
}

static BOOL isGreen(CGFloat r, CGFloat g, CGFloat b) {
    static const uint32_t greens[] = {0x1ED760, 0x1DB954};
    for (NSUInteger i = 0; i < sizeof(greens) / sizeof(greens[0]); i++) {
        CGFloat gr, gg, gb; unpackRGB(greens[i], &gr, &gg, &gb);
        if (fabs(r - gr) <= 0.02 && fabs(g - gg) <= 0.02 && fabs(b - gb) <= 0.02) return YES;
    }
    return NO;
}

static BOOL isCurrentDynamic(CGFloat r, CGFloat g, CGFloat b) {
    CGFloat ar, ag, ab, pr, pg, pb;
    unpackRGB(sg_dynamic_rgb, &ar, &ag, &ab);
    unpackRGB(sg_previous_rgb, &pr, &pg, &pb);
    return (fabs(r-ar) <= 0.02 && fabs(g-ag) <= 0.02 && fabs(b-ab) <= 0.02) ||
           (fabs(r-pr) <= 0.02 && fabs(g-pg) <= 0.02 && fabs(b-pb) <= 0.02);
}

static void updateVisibleUI(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIColor *accent = SGDynamicAccentColor();
        if (!accent) return;

        for (UIWindow *window in UIApplication.sharedApplication.windows) {
            if (window.hidden || window.alpha < 0.01) continue;

            NSMutableArray<UIView *> *stack = [NSMutableArray arrayWithObject:window];
            while (stack.count) {
                UIView *view = stack.lastObject;
                [stack removeLastObject];

                CGFloat r, g, b, a;
                if (view.tintColor &&
                    [view.tintColor getRed:&r green:&g blue:&b alpha:&a] &&
                    (isGreen(r,g,b) || isCurrentDynamic(r,g,b))) {
                    view.tintColor = accent;
                }

                if (view.backgroundColor &&
                    [view.backgroundColor getRed:&r green:&g blue:&b alpha:&a] &&
                    (isGreen(r,g,b) || isCurrentDynamic(r,g,b))) {
                    view.backgroundColor = accent;
                }

                if ([view isKindOfClass:UILabel.class]) {
                    UILabel *label = (UILabel *)view;
                    if ([label.textColor getRed:&r green:&g blue:&b alpha:&a] &&
                        (isGreen(r,g,b) || isCurrentDynamic(r,g,b))) {
                        label.textColor = accent;
                    }
                }

                for (UIView *subview in view.subviews) [stack addObject:subview];

                CALayer *layer = view.layer;
                if (layer) {
                    if (layer.backgroundColor) {
                        const CGFloat *c = CGColorGetComponents(layer.backgroundColor);
                        size_t count = CGColorGetNumberOfComponents(layer.backgroundColor);
                        if (count == 4 && (isGreen(c[0],c[1],c[2]) || isCurrentDynamic(c[0],c[1],c[2])))
                            layer.backgroundColor = accent.CGColor;
                    }

                    for (CALayer *sub in layer.sublayers ?: @[]) {
                        if (sub.backgroundColor) {
                            const CGFloat *c = CGColorGetComponents(sub.backgroundColor);
                            size_t count = CGColorGetNumberOfComponents(sub.backgroundColor);
                            if (count == 4 && (isGreen(c[0],c[1],c[2]) || isCurrentDynamic(c[0],c[1],c[2])))
                                sub.backgroundColor = accent.CGColor;
                        }
                        if ([sub isKindOfClass:CAShapeLayer.class]) {
                            CAShapeLayer *shape = (CAShapeLayer *)sub;
                            if (shape.fillColor) {
                                const CGFloat *c = CGColorGetComponents(shape.fillColor);
                                if (CGColorGetNumberOfComponents(shape.fillColor) == 4 &&
                                    (isGreen(c[0],c[1],c[2]) || isCurrentDynamic(c[0],c[1],c[2])))
                                    shape.fillColor = accent.CGColor;
                            }
                            if (shape.strokeColor) {
                                const CGFloat *c = CGColorGetComponents(shape.strokeColor);
                                if (CGColorGetNumberOfComponents(shape.strokeColor) == 4 &&
                                    (isGreen(c[0],c[1],c[2]) || isCurrentDynamic(c[0],c[1],c[2])))
                                    shape.strokeColor = accent.CGColor;
                            }
                        }
                    }
                }
                [view setNeedsLayout];
                [view setNeedsDisplay];
            }
            [window setNeedsLayout];
            [window setNeedsDisplay];
        }
    });
}

UIColor *SGDynamicAccentColor(void) {
    CGFloat r, g, b; unpackRGB(sg_dynamic_rgb, &r, &g, &b);
    return [UIColor colorWithRed:r green:g blue:b alpha:1];
}

static void artworkChanged(NSNotification *note) {
    if (!SGDynamicAccentEnabled()) return;
    UIImage *image = note.userInfo[@"image"];
    if (!image) return;

    uint32_t next = accentFromImage(image);
    if (sg_dynamic_ready && next == sg_dynamic_rgb) return;

    sg_previous_rgb = sg_dynamic_rgb;
    sg_dynamic_rgb = next;
    sg_dynamic_ready = YES;

    // Cross-dissolve visible controls immediately; new controls pick the colour through the
    // Accent.x hooks below.
    [UIView performWithoutAnimation:^{
        updateVisibleUI();
    }];
}

%hook UIColor
- (UIColor *)initWithRed:(CGFloat)r green:(CGFloat)g blue:(CGFloat)b alpha:(CGFloat)a {
    if (SGDynamicAccentEnabled() && (isGreen(r,g,b) || isCurrentDynamic(r,g,b))) {
        CGFloat ar, ag, ab; unpackRGB(sg_dynamic_rgb, &ar, &ag, &ab);
        r = ar; g = ag; b = ab;
    }
    return %orig(r,g,b,a);
}
+ (UIColor *)colorWithRed:(CGFloat)r green:(CGFloat)g blue:(CGFloat)b alpha:(CGFloat)a {
    if (SGDynamicAccentEnabled() && (isGreen(r,g,b) || isCurrentDynamic(r,g,b))) {
        CGFloat ar, ag, ab; unpackRGB(sg_dynamic_rgb, &ar, &ag, &ab);
        r = ar; g = ag; b = ab;
    }
    return %orig(r,g,b,a);
}
%end

%hook CAShapeLayer
- (void)setFillColor:(CGColorRef)color {
    if (SGDynamicAccentEnabled() && color && CGColorGetNumberOfComponents(color) == 4) {
        const CGFloat *c = CGColorGetComponents(color);
        if (isGreen(c[0],c[1],c[2]) || isCurrentDynamic(c[0],c[1],c[2]))
            color = SGDynamicAccentColor().CGColor;
    }
    %orig(color);
}
- (void)setStrokeColor:(CGColorRef)color {
    if (SGDynamicAccentEnabled() && color && CGColorGetNumberOfComponents(color) == 4) {
        const CGFloat *c = CGColorGetComponents(color);
        if (isGreen(c[0],c[1],c[2]) || isCurrentDynamic(c[0],c[1],c[2]))
            color = SGDynamicAccentColor().CGColor;
    }
    %orig(color);
}
%end

@interface SGDynamicAccentObserver : NSObject @end
@implementation SGDynamicAccentObserver
- (void)changed:(NSNotification *)note { artworkChanged(note); }
@end

%ctor {
    SGDynamicAccentObserver *observer = [SGDynamicAccentObserver new];
    [NSNotificationCenter.defaultCenter addObserver:observer
                                             selector:@selector(changed:)
                                                 name:@"spotifyglass.redesign.nowPlayingArtworkDidChange"
                                               object:nil];
    static SGDynamicAccentObserver *keepAlive;
    keepAlive = observer;
}
