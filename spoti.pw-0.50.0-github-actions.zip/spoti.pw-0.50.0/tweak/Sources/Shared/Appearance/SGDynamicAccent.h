#import <UIKit/UIKit.h>

/// Live accent derived from the current now-playing artwork. Does not modify the persistent
/// accent preference; it is only a runtime colour source.
BOOL SGDynamicAccentEnabled(void);
uint32_t SGDynamicAccentRGB(void);
UIColor *SGDynamicAccentColor(void);
