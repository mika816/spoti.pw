# Dynamic Accent Color patch

This patch adds runtime album-art based accent colors to spoti.pw 0.50.0.

## What changed

- Added `tweak/Sources/Shared/Appearance/SGDynamicAccent.h`
- Added `tweak/Sources/Shared/Appearance/SGDynamicAccent.x`
- Updated native `tweak/Sources/Native/Appearance/Accent.x`
- Updated redesigned `tweak/Sources/Redesigned/Kit/SGRAccent.x`

## Runtime behavior

The patch listens for `spotifyglass.redesign.nowPlayingArtworkDidChange`, which is already
published by the existing artwork bridge. It samples the current `UIImage`, chooses a vibrant
mid-tone color, clamps it for readability on Spotify's dark UI, and applies it live to new and
already visible green UI elements.

The persistent accent preference is not changed, so the dynamic color does not require an app
restart.

## Build

The repository's normal Theos build is still required to produce the final dylib/IPA. This
environment does not contain Xcode/Theos, so no binary IPA was claimed as built or tested.
